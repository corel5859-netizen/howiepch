# HowiePCH — repaired production-ready demo

## What changed
- `/` now serves the actual HowiePCH public website.
- `/login` is the administrator login.
- `/admin` is the protected admin dashboard.
- Added public account signup/login with secure HTTP-only cookie sessions.
- Added working demo games that award points.
- Added reward listing and point redemption records.
- Removed the user-to-user Messages feature completely.
- Added validation, login/signup rate limiting, security headers and safer role handling.
- Admin/staff account creation records `createdBy`, creation time and optional expiry.
- Audit logs are capped to prevent unlimited growth.

## Run locally
1. Install Node.js 18+.
2. `npm install`
3. Set a strong `JWT_SECRET` (32+ random characters).
4. Optional: set `INITIAL_ADMIN_PASSWORD` before the first run.
5. `npm start`
6. Open `http://localhost:3000/`.

## Production
Use HTTPS and a real persistent database for a high-traffic site. Set `NODE_ENV=production`, `JWT_SECRET`, and a strong `INITIAL_ADMIN_PASSWORD` before first start. Do not publish the admin credentials. Put the app behind a production reverse proxy/hosting service and configure backups.

The games and rewards in this package are fictional/demo functionality and do not process real money or represent Publishers Clearing House.

## Docker deployment
Copy `.env.example` to `.env`, set the secrets, then run `docker compose up -d --build`. Put HTTPS/domain routing in front of the container using your hosting provider or reverse proxy.
