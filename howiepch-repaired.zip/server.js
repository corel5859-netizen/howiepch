const express = require('express');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
const COOKIE_SECURE = process.env.NODE_ENV === 'production';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const DB = path.join(DATA_DIR, 'data.json');
const PUBLIC = path.join(__dirname, 'public');
const SITE = path.join(__dirname, 'site');

if (!JWT_SECRET || JWT_SECRET.length < 32) {
  if (process.env.NODE_ENV === 'production') throw new Error('JWT_SECRET must be set and at least 32 characters in production.');
  console.warn('WARNING: Set JWT_SECRET to a random secret of at least 32 characters before production.');
}

app.disable('x-powered-by');
app.use(express.json({ limit: '50kb' }));
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});

const attempts = new Map();
function rateLimit(key, max = 10, windowMs = 15 * 60 * 1000) {
  const now = Date.now();
  const old = attempts.get(key) || [];
  const fresh = old.filter(t => now - t < windowMs);
  fresh.push(now);
  attempts.set(key, fresh);
  return fresh.length <= max;
}

function emptyDb() {
  const now = new Date().toISOString();
  const password = bcrypt.hashSync(process.env.INITIAL_ADMIN_PASSWORD || 'admin123', 12);
  return {
    nextUserId: 2,
    users: [{ id: 1, username: 'admin', password, role: 'admin', points: 0, createdBy: 'system', createdAt: now, expiresAt: null }],
    audit: [{ time: now, actor: 'system', action: 'CREATE_ACCOUNT', target: 'admin', details: 'Initial administrator created' }],
    rewards: [
      { id: 1, name: 'HowiePCH Gift Card', description: 'Demo reward for the fictional platform.', points: 1000, active: true },
      { id: 2, name: 'Premium Reward', description: 'Demo reward for the fictional platform.', points: 2500, active: true },
      { id: 3, name: 'Grand Reward', description: 'Demo reward for the fictional platform.', points: 5000, active: true }
    ],
    redemptions: []
  };
}
function load() {
  if (!fs.existsSync(DB)) save(emptyDb());
  const data = JSON.parse(fs.readFileSync(DB, 'utf8'));
  data.users ||= []; data.audit ||= []; data.rewards ||= []; data.redemptions ||= [];
  return data;
}
function save(data) { fs.writeFileSync(DB, JSON.stringify(data, null, 2)); }
function publicUser(u) { return { id: u.id, username: u.username, role: u.role, points: u.points || 0, expiresAt: u.expiresAt || null }; }
function tokenFor(u) { return jwt.sign({ id: u.id, username: u.username, role: u.role }, JWT_SECRET || 'dev-only-secret', { expiresIn: '8h' }); }
function setAuth(res, u) {
  res.cookie('session', tokenFor(u), { httpOnly: true, sameSite: 'lax', secure: COOKIE_SECURE, maxAge: 8 * 60 * 60 * 1000 });
}
function clearAuth(res) { res.clearCookie('session'); }
function readToken(req) {
  const cookie = req.headers.cookie?.split(';').map(x => x.trim()).find(x => x.startsWith('session='));
  if (cookie) return decodeURIComponent(cookie.slice(8));
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7) : null;
}
function auth(req, res, next) {
  try {
    const decoded = jwt.verify(readToken(req) || '', JWT_SECRET || 'dev-only-secret');
    const d = load();
    const u = d.users.find(x => x.id === decoded.id);
    if (!u || (u.expiresAt && new Date(u.expiresAt) <= new Date())) return res.status(401).json({ error: 'Session expired or account unavailable' });
    req.user = u;
    next();
  } catch { res.status(401).json({ error: 'Unauthorized' }); }
}
function adminOnly(req, res, next) { if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin only' }); next(); }
function audit(data, actor, action, target, details = '') { data.audit.unshift({ time: new Date().toISOString(), actor, action, target, details }); data.audit = data.audit.slice(0, 5000); }
function validUsername(v) { return typeof v === 'string' && /^[a-zA-Z0-9_]{3,30}$/.test(v); }
function validPassword(v) { return typeof v === 'string' && v.length >= 8 && v.length <= 128; }

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'HowiePCH' }));

app.post('/api/signup', (req, res) => {
  if (!rateLimit(`signup:${req.ip}`, 5, 60 * 60 * 1000)) return res.status(429).json({ error: 'Too many signup attempts. Try again later.' });
  const { username, password } = req.body || {};
  if (!validUsername(username)) return res.status(400).json({ error: 'Username must be 3-30 letters, numbers or underscores.' });
  if (!validPassword(password)) return res.status(400).json({ error: 'Password must be 8-128 characters.' });
  const d = load();
  if (d.users.some(u => u.username.toLowerCase() === username.toLowerCase())) return res.status(409).json({ error: 'Username already exists.' });
  const now = new Date().toISOString();
  const u = { id: d.nextUserId++, username, password: bcrypt.hashSync(password, 12), role: 'user', points: 0, createdBy: 'self-signup', createdAt: now, expiresAt: null };
  d.users.push(u); audit(d, username, 'SIGNUP', username, 'Public account created'); save(d); setAuth(res, u);
  res.status(201).json({ user: publicUser(u) });
});

app.post('/api/login', (req, res) => {
  if (!rateLimit(`login:${req.ip}`, 10)) return res.status(429).json({ error: 'Too many login attempts. Try again later.' });
  const { username, password } = req.body || {};
  const d = load(), u = d.users.find(x => x.username.toLowerCase() === String(username || '').toLowerCase());
  if (!u || !bcrypt.compareSync(password || '', u.password)) return res.status(401).json({ error: 'Invalid username or password' });
  if (u.expiresAt && new Date(u.expiresAt) <= new Date()) return res.status(403).json({ error: 'This account has expired' });
  audit(d, u.username, 'LOGIN', u.username, 'Successful login'); save(d); setAuth(res, u);
  res.json({ user: publicUser(u) });
});
app.post('/api/logout', auth, (req, res) => { clearAuth(res); res.json({ ok: true }); });
app.get('/api/me', auth, (req, res) => res.json({ user: publicUser(req.user) }));

app.post('/api/games/:id/play', auth, (req, res) => {
  const allowed = new Set(['quick-draw', 'daily-puzzle', 'challenge']);
  if (!allowed.has(req.params.id)) return res.status(404).json({ error: 'Game not found' });
  const d = load(), u = d.users.find(x => x.id === req.user.id);
  const reward = req.params.id === 'quick-draw' ? 25 : req.params.id === 'daily-puzzle' ? 40 : 60;
  u.points = (u.points || 0) + reward;
  audit(d, u.username, 'PLAY_GAME', req.params.id, `Awarded ${reward} points`); save(d);
  res.json({ pointsAwarded: reward, points: u.points });
});
app.get('/api/rewards', (req, res) => res.json(load().rewards.filter(r => r.active)));
app.post('/api/rewards/:id/redeem', auth, (req, res) => {
  const d = load(), u = d.users.find(x => x.id === req.user.id), r = d.rewards.find(x => x.id === Number(req.params.id) && x.active);
  if (!r) return res.status(404).json({ error: 'Reward not found' });
  if ((u.points || 0) < r.points) return res.status(400).json({ error: 'Not enough points' });
  u.points -= r.points;
  d.redemptions.push({ id: d.redemptions.length + 1, userId: u.id, rewardId: r.id, points: r.points, time: new Date().toISOString(), status: 'pending' });
  audit(d, u.username, 'REDEEM_REWARD', r.name, `${r.points} points`); save(d);
  res.json({ ok: true, points: u.points, reward: r.name });
});

app.get('/api/accounts', auth, adminOnly, (req, res) => res.json(load().users.map(u => ({ ...publicUser(u), createdBy: u.createdBy, createdAt: u.createdAt }))));
app.post('/api/accounts', auth, adminOnly, (req, res) => {
  const { username, password, role = 'staff', expiresHours = null } = req.body || {};
  if (!validUsername(username)) return res.status(400).json({ error: 'Username must be 3-30 letters, numbers or underscores.' });
  if (!validPassword(password)) return res.status(400).json({ error: 'Password must be 8-128 characters.' });
  if (!['admin', 'staff'].includes(role)) return res.status(400).json({ error: 'Invalid role.' });
  const d = load(); if (d.users.some(u => u.username.toLowerCase() === username.toLowerCase())) return res.status(409).json({ error: 'Username already exists' });
  const createdAt = new Date(); let expiresAt = null;
  if (expiresHours !== null && expiresHours !== '') { const h = Number(expiresHours); if (!Number.isFinite(h) || h <= 0 || h > 8760) return res.status(400).json({ error: 'Expiry must be between 1 and 8760 hours.' }); expiresAt = new Date(createdAt.getTime() + h * 3600000).toISOString(); }
  const u = { id: d.nextUserId++, username, password: bcrypt.hashSync(password, 12), role, points: 0, createdBy: req.user.username, createdAt: createdAt.toISOString(), expiresAt };
  d.users.push(u); audit(d, req.user.username, 'CREATE_ACCOUNT', username, `Role=${role}; expiresAt=${expiresAt || 'never'}`); save(d);
  res.status(201).json({ ok: true, user: publicUser(u), createdBy: u.createdBy, createdAt: u.createdAt });
});
app.delete('/api/accounts/:id', auth, adminOnly, (req, res) => {
  const d = load(), id = Number(req.params.id), u = d.users.find(x => x.id === id);
  if (!u) return res.status(404).json({ error: 'Account not found' });
  if (u.id === req.user.id || u.username === 'admin') return res.status(400).json({ error: 'This administrator cannot be deleted here.' });
  d.users = d.users.filter(x => x.id !== id); audit(d, req.user.username, 'DELETE_ACCOUNT', u.username, 'Account deleted'); save(d); res.json({ ok: true });
});
app.get('/api/audit', auth, adminOnly, (req, res) => res.json(load().audit));

app.use(express.static(PUBLIC));
app.use('/site', express.static(SITE));
app.get('/admin', (req, res) => res.sendFile(path.join(PUBLIC, 'admin.html')));
app.get('/login', (req, res) => res.sendFile(path.join(PUBLIC, 'login.html')));
app.get('*', (req, res) => res.sendFile(path.join(SITE, 'index.html')));

app.listen(PORT, () => console.log(`HowiePCH running on port ${PORT}`));
